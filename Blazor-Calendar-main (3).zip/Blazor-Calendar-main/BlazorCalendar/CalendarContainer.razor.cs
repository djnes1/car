﻿namespace BlazorCalendar; 

partial class CalendarContainer : CalendarBase
{
}
